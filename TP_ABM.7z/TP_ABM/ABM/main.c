#include "function.h"

#define SIZEEMPLOY 10
#define SIZESEC 5




int main()
{
    char seguir = 's';
    char confirmar;

eEmployee employee[SIZEEMPLOY];

/*LLAMADA DE FUNCIONES*/
generateEmployee (employee,SIZEEMPLOY);
initEmployees(employee, SIZEEMPLOY);

    do
    {
        switch(menu())
        {
        case 1:

            newEmployee(employee, SIZEEMPLOY);  //Alta empleado~
            system("pause");
            break;

        case 2:

            removeEmployee(employee, SIZEEMPLOY);     //Baja empleado~
            system("pause");
            break;

        case 3:

            modifyEmployee(employee, SIZEEMPLOY);    //Modificar empleado~
            system("pause");
            break;
        case 4:
            printEmployees(employee, SIZEEMPLOY);	 //Imprimir lista empleados~
            system("pause");
            break;
        case 5:
            seekEmployeeById(employee, SIZEEMPLOY);  //Busca empleados por Id~
            system("pause");
            break;
        case 6:
            switch(menuInfo()){
                case 1:
                        switch(menuAlpha()){
                            case 1:
                                    sortEmployeesUpward(employee, SIZEEMPLOY);
                                break;
                            case 2:
                                    sortEmployeesDecendent(employee, SIZEEMPLOY);
                                break;
                      }
                      break;
                case 2:
                      totalEmployees(employee, SIZEEMPLOY); //Total empleados y promedio de sueldos~
                      system("pause");
                      break;
                case 3:
                     employeeExceedsAverage(employee, SIZEEMPLOY); //Empleados que superan el sueldopromedio~
                     system("pause");
                      break;
            }
            break;

        case 7:
            printf("\nConfirmar salida ?  S o N: \n\n"); //s o n para salir
            fflush(stdin);
            confirmar = getche();

            if(tolower(confirmar) == 's'){
                seguir = 'n';
            }
            system("\npause\n");
            break;

        default:
            printf("\nOpcion invalida. Reingrese.\n\n");
            system("pause");
        }
    }
    while(seguir == 's');
    return 0;
}
