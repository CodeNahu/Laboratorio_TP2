#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>

/** \brief  Estructura eEmployee representa los datos de un empleado.
 */
typedef struct {
    int id;
    char name[51];
    char lastName[51];
    float salary;
    int sector;
    int isEmpty;
} eEmployee;

//--------------------------------------------------------------------------------- //pongo estas lineas para diferenciar mejor.
/** \brief Permite buscar un empleado por su numero de legajo.
 *\param Estructuta de empleado.
 *\param Tama�o de la estructura como entero.
 *\param Entero ingresado por el usuario.
 * \return Devuelve un n�mero entero entre -1 y el tama�o de la estructura.
 */
int seekEmployee(eEmployee list[], int len, int file);

//---------------------------------------------------------------------------------
/** \brief Despliega en pantalla un listado de empleados activos.
 *\param Estructuta de empleado.
 *\param Tama�o de la estructura como entero.
 * \return Devuelve 0
 */
int printEmployees(eEmployee list[], int len);
//---------------------------------------------------------------------------------

/** \brief Busca en el Array de empleados un espacio libre o empleado inactivo.
 *\param Estructuta de empleado.
 *\param Tama�o de la estructura como entero.
 * \return Devuelve un n�mero entero entre -1 y el tama�o de la estructura.
 */
int seekFree(eEmployee list[], int len);
//---------------------------------------------------------------------------------

/** \brief Despliega menu principal de opciones en pantalla.
 * \return Devuelve 0
 */
int menu();
//----------------------------------------------------------------------------------

/** \brief Despliega submenu de opciones en pantalla.
 * \return Devuelve 0
 */
int menuAlpha();
//---------------------------------------------------------------------------------

/** \brief Despliega submenu de opciones en pantalla.
 * \return Devuelve 0
 */
int menuInfo();
//---------------------------------------------------------------------------------

/** \brief Despliega lista de empleados que superan el sueldo promedio.
 *\param Estructuta de empleado.
 *\param Tama�o de la estructura como entero.
 * \return
 */
void employeeExceedsAverage(eEmployee list[], int leng);
//---------------------------------------------------------------------------------

/** \brief Permite ingresar un numero de legajo y mostrar los datos del empleado en pantalla, si es que existe.
 *\param Estructuta de empleado.
 *\param Tama�o de la estructura como entero.
 *\param Entero ingresado por el usuario.
 * \return
 */
void seekEmployeeById(eEmployee list[], int len);
//---------------------------------------------------------------------------------

/** \brief Genera un listado de empleados, los busca por Id.
 * \return
 */
void generateEmployee(eEmployee list[], int len);
//---------------------------------------------------------------------------------

/** \brief Permite agregar un empleado nuevo al usuario, en caso que sea posible.
 *\param Estructuta de empleado.
 *\param Tama�o de la estructura como entero.
 * \return
 */
void newEmployee(eEmployee list[], int len);
//---------------------------------------------------------------------------------

/** \brief Inhabilita a todos los empleados, realiza una baja logica general.
 *\param Estructuta de empleado.
 *\param Tama�o de la estructura como entero.
 * \return
 */
void initEmployees(eEmployee list[], int len);
//---------------------------------------------------------------------------------

/** \brief Permite modificar el sueldo de un empleado.
 *\param Estructuta de empleado.
 *\param Tama�o de la estructura como entero.
 * \return
 */
void modifyEmployee(eEmployee list[], int len);
//---------------------------------------------------------------------------------

/** \brief Realiza la baja logica de un empleado elegido por el usuario.
 *\param Estructuta de empleado.
 *\param Tama�o de la estructura como entero.
 * \return
 */
void removeEmployee(eEmployee list[], int len);
//---------------------------------------------------------------------------------

/** \brief Ordena de forma ascendente por apellido y muestra en pantalla el listado de empleados,
           Si el apellido es el mismo los ordena por sector.
 *\param Estructuta de empleado.
 *\param Tama�o de la estructura como entero.
 * \return
 */
void sortEmployeesUpward(eEmployee list[], int len);
//---------------------------------------------------------------------------------

/** \brief Ordena de forma decendente por apellido y muestra en pantalla el listado de empleados,
           Si el apellido es el mismo los ordena por sector.
 *\param Estructuta de empleado.
 *\param Tama�o de la estructura como entero.
 * \return
 */
void sortEmployeesDecendent(eEmployee list[], int len);
//---------------------------------------------------------------------------------

/** \brief Se utiliza en otras funcines, muestra un empleado de la nomina.
 * \return
 */
void printEmployee(eEmployee list);
//---------------------------------------------------------------------------------

/** \brief Indica en pantalla cuantos empleados activos existen y el promedio total de sueldos.
 *\param Estructuta de empleado.
 *\param Tama�o de la estructura como entero.
 * \return
 */
void totalEmployees(eEmployee list[], int len);
//---------------------------------------------------------------------------------


